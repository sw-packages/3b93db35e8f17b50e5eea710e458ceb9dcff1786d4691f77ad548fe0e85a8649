Plan
----

- [ ] Implement expected.then() etc.
- [x] Write CMake files
- [x] Check code against current Dxxxxr0 and adapt
- [x] Expand README.md
- [x] Expand test/expected.t.cpp
- [x] Improve use of travis matrix
